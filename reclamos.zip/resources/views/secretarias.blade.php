<x-layouts.app :title="__('Secretarías')">
    <livewire:abm-secretarias />
</x-layouts.app>