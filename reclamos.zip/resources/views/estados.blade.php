<x-layouts.app :title="__('Estados')">
    <livewire:abm-estados />
</x-layouts.app>
