<div class="container mx-auto p-4">
    <livewire:alta-reclamo 
        :show-persona-form="true" 
        :redirect-after-save="route('home')"
        success-message="Su reclamo ha sido registrado exitosamente. Recibirá una notificación con el número de seguimiento." />
</div>