<x-layouts.auth.card :title="$title ?? null">
    {{ $slot }}
</x-layouts.auth.card>
