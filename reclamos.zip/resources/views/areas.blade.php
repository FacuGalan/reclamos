<x-layouts.app :title="__('Áreas')">
    <livewire:abm-areas />
</x-layouts.app>