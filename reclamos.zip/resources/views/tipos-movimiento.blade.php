<x-layouts.app :title="__('Tipos de Movimiento')">
    <livewire:abm-tipos-movimiento />
</x-layouts.app>