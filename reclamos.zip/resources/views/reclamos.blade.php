<x-layouts.app :title="__('Reclamos')">
    <livewire:abm-reclamos />
</x-layouts.app>
